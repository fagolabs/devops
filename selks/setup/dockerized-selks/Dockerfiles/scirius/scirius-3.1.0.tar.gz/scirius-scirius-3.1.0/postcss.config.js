module.exports = {
  parser: "sugarss",
  plugins: {
    autoprefixer: {}
  }
};