export default {
    HUNT_FILTER: {
        SEE_UNTAGGED: 'U',
        SEE_INFORMATIONAL: 'I',
        SEE_RELEVANT: 'R',
        SEE_ALL: 'A'
    },
}
