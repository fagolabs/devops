Introduction
============

Scirius Community Edition is a web interface dedicated to Suricata ruleset management.
It handles the rules file and update associated files.

.. image:: images/suricata-index.png
    :alt: suricata update in scirius
    :align: center

Scirius CE is developed by `Stamus Networks <https://www.stamus-networks.com/>`_ and is available under the
GNU GPLv3 license.
