.. Scirius documentation master file, created by
   sphinx-quickstart on Sat Feb 24 23:22:32 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Scirius's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro-ce
   installation-ce
   local-user-management
   ruleset
   hunt
   suricata-ce
   backup-ce
