import os
import requests
import json
import configparser
from flask import Flask, flash, request, redirect, url_for

app = Flask(__name__)

INTERMEDIATE_KEYSTONE_CONFIG_FILE = "/intermediate_keystone.conf"
CURRENT_WORKING_DIR = os.path.dirname(os.path.realpath(__file__))
KEYSTONE_TOKEN_AUTHEN_URL = "https://os-controller:35357/v3/auth/tokens"
KEYSTONE_CERT_PATH = "/openstack.crt"
INTERMEDIATE_KEYSTONE_ADDRESS = "192.168.30.166"
INTERMEDIATE_KEYSTONE_PORT = 3004

config_info = {"keystone_cert_path": "keystone_cert_path",
               "rgw_keystone_url": "rgw_keystone_url",
               "keystone_endpoint_for_intermediate_keystone": "keystone_endpoint_for_intermediate_keystone",
               "rgw_keystone_api_version": "rgw_keystone_api_version"}

radosgw_token = ""

def update_config(config_file_path):
    config_dict = None
    with open(config_file_path, 'r') as f:
        config_dict = json.loads(f.read().replace('\n', ''))
    rgw_config_file_path = config_dict['config_file_path']
    client_name = config_dict['client_name']
    config = configparser.ConfigParser()
    config.read(rgw_config_file_path)
    global KEYSTONE_TOKEN_AUTHEN_URL
    KEYSTONE_TOKEN_AUTHEN_URL = config.get(client_name, config_info['keystone_endpoint_for_intermediate_keystone'])
    if config.get(client_name, config_info["rgw_keystone_api_version"]) == "3":
        if "v3" in KEYSTONE_TOKEN_AUTHEN_URL:
            if KEYSTONE_TOKEN_AUTHEN_URL[-1] == '/':
                KEYSTONE_TOKEN_AUTHEN_URL += "auth/tokens"
            else:
                KEYSTONE_TOKEN_AUTHEN_URL += "/auth/tokens"
    else:
        if KEYSTONE_TOKEN_AUTHEN_URL[-1] == '/':
            KEYSTONE_TOKEN_AUTHEN_URL += "v3/auth/tokens"
        else:
            KEYSTONE_TOKEN_AUTHEN_URL += "/v3/auth/tokens"
    global KEYSTONE_CERT_PATH
    KEYSTONE_CERT_PATH = config.get(client_name, config_info['keystone_cert_path'])
    fake_keystone_url = config.get(client_name, config_info['rgw_keystone_url'])
    fake_keystone_url = fake_keystone_url.replace("http://", "").replace("/fake_authen", "").split(":")
    global INTERMEDIATE_KEYSTONE_ADDRESS
    INTERMEDIATE_KEYSTONE_ADDRESS = fake_keystone_url[0]
    global INTERMEDIATE_KEYSTONE_PORT
    INTERMEDIATE_KEYSTONE_PORT = int(fake_keystone_url[1])


def get_correct_header_from_flask_header(flask_header):
    # flask header is an instance of flask.request.headers.__dict__
    h1 = flask_header['_store']
    for key in h1:
        h1[key] = h1[key][1]
    return h1

@app.route('/fake_authen/v3/auth/tokens', methods=['GET', 'POST'])
def fake_authen():

    print("hungdh9_request_method = %s" % request.method)
    print("hungdh9_request.url = %s" % request.url)
    print("hungdh9_request.data = %s" % request.data)
    print("hungdh9_request.method = %s" % request.method)
    print("hungdh9_request.headers = %s\n" % request.headers)

    if request.method in ['GET']:
        _url = KEYSTONE_TOKEN_AUTHEN_URL
        x_subject_token = request.headers.get('X-Subject-Token')
        x_auth_token = request.headers.get('X-Auth-Token')
        # if not x_auth_token:
        #     x_auth_token = radosgw_token
        _header = {"X-Subject-Token": x_subject_token,
                   "X-Auth-Token": x_auth_token}
        ca_path = KEYSTONE_CERT_PATH

        r = requests.get(url=_url, headers=_header, verify=ca_path)
        # r = requests.get(url=_url, headers=_header)

        print("request.data = %s" % request.data)
        print("request.method = %s" % request.method)
        print("_header = %s" % _header)
        print("_url = %s" % _url)
        print("r.status_code = %s" % r.status_code)
        print("r.content = %s" % r.content)
        print("r.headers.__dict__ = %s" % r.headers.__dict__)
        print("r.headers = %s" % r.headers)
        print("type(r.headers.__dict__)=%s" % type(r.headers.__dict__))
        print("type(r.headers)=%s" % type(r.headers))

        print("request.headers = %s\n" % request.headers)

        # for a in request.headers:
        #     print("%s = %s\n\n" % (a, request.headers[a]))

        if r.status_code == 200:
            resp_header = get_correct_header_from_flask_header(r.headers.__dict__)
            resp_data = r.json()

            response = app.response_class(
                response=json.dumps(resp_data),
                status=200,
                mimetype='application/json',
                headers=resp_header
            )
            return response

        else:
            response = app.response_class(
                response="Authen failed!",
                status=400,
                mimetype='application/json'
            )
            return response

    if request.method in ['POST']:
        ca_path = KEYSTONE_CERT_PATH
        _url = KEYSTONE_TOKEN_AUTHEN_URL
        body = request.data
        r = requests.post(url=_url, data=body, verify=ca_path)

        print("r.status_code = %s" % r.status_code)
        print("r.headers.__dict__ = %s" % r.headers.__dict__)
        print("r.headers = %s" % r.headers)
        print("type(r.headers.__dict__)=%s" % type(r.headers.__dict__))
        print("type(r.headers)=%s" % type(r.headers))
        print("body = %s" % r.json())

        if r.status_code == 201:
            # global radosgw_token
            # radosgw_token = r.headers.__dict__['_store']['x-subject-token'][1]
            print("radosgw_token=%s" % radosgw_token)
            resp_header = get_correct_header_from_flask_header(r.headers.__dict__)
            resp_data = r.json()
            response = app.response_class(
                response=json.dumps(resp_data),
                status=201,
                mimetype='application/json',
                headers=resp_header
            )
            return response

def main():
    update_config(INTERMEDIATE_KEYSTONE_CONFIG_FILE)
    app.run(host=INTERMEDIATE_KEYSTONE_ADDRESS, port=INTERMEDIATE_KEYSTONE_PORT, debug=True)

if __name__ == "__main__":
    main()